# SAYBOOK

Book-architecture SaaS built around the client's **Double Helix Map (DHM)**.
Read `docs/STAGE1_PLAN.md` first (analysis, architecture, schema, open questions).

## Status

| Part | State |
|---|---|
| Plan configuration, DHM domain core, SAY syntax | Built, type-checked, tested |
| Database schema + RLS | Built, tested on local Postgres 16 (not yet on a real Supabase project) |
| Next.js app (UI, auth, DHM workspace, PDF) | **Not started** — Stage 2 |

The Next.js scaffold could not be generated in the first session because that sandbox blocked the npm registry. Everything here is framework-independent and drops straight into a Next.js project.

## Bootstrap the Next.js app (Stage 2)

Requires Node 22+.

```bash
# 1. Scaffold somewhere else, then copy this folder's contents over it
npx create-next-app@latest saybook-app --typescript --tailwind --eslint --app --src-dir --import-alias "@/*" --use-npm
cp -r docs supabase scripts tsconfig.core.json .env.example .gitignore ../saybook-app/
cp -r src/lib ../saybook-app/src/
cd ../saybook-app && npm install @supabase/supabase-js @supabase/ssr zod lucide-react pdf-lib
```

In the generated `tsconfig.json` add `"allowImportingTsExtensions": true` (the domain files import each other with `.ts` so they also run directly under Node).

## Checks you can run now (no install needed beyond Node 22.18+)

```bash
node scripts/verify-core.mts            # 21 domain checks
tsc -p tsconfig.core.json               # strict type-check (needs typescript + @types/node)
```

Schema tests (needs a local Postgres):

```bash
createdb saybook_test
psql -v ON_ERROR_STOP=1 -d saybook_test \
  -f supabase/tests/00_auth_stub.sql \
  -f supabase/migrations/0001_init.sql \
  -f supabase/tests/schema_test.sql
# expected last line: ALL SCHEMA TESTS PASSED
```

`00_auth_stub.sql` fakes Supabase's `auth` schema for local testing. **Do not run it on Supabase.**

## Supabase setup

1. Create a project; copy URL and anon key into `.env.local` (see `.env.example`).
2. SQL editor: run `supabase/migrations/0001_init.sql` (or `supabase db push`).
3. Auth → URL configuration: set Site URL and add `/reset-password` as a redirect.
4. Until payments exist, grant a plan to a test user with the service role:
   `insert into public.user_subscriptions (user_id, plan_id) values ('<auth user id>', 'basic');`

## Rules for contributors

- Plan numbers live **only** in `src/lib/plans.ts` (and the matching seed in the migration — `verify-core` fails if they diverge).
- No fake data, no placeholder buttons; unfinished features stay unlinked.
- Secrets only in `.env.local`; the service-role key is server-only.
