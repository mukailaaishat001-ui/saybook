-- Behavioral tests for 0001_init.sql. Run after 00_auth_stub.sql + the migration:
--   psql -v ON_ERROR_STOP=1 -f supabase/tests/00_auth_stub.sql -f supabase/migrations/0001_init.sql -f supabase/tests/schema_test.sql
\set ON_ERROR_STOP on
grant usage on schema public to authenticated;
grant select, insert, update, delete on all tables in schema public to authenticated;

create function public.t_fails(q text, must_contain text default '') returns void
language plpgsql as $$
begin
  execute q;
  raise exception 'EXPECTED FAILURE BUT SUCCEEDED: %', q;
exception when others then
  if sqlerrm like 'EXPECTED FAILURE%' then raise; end if;
  if must_contain <> '' and position(lower(must_contain) in lower(sqlerrm)) = 0 then
    raise exception 'Wrong error for [%]: got [%], wanted [%]', q, sqlerrm, must_contain;
  end if;
end $$;
create function public.t_login(uid uuid) returns void language sql as $$
  select set_config('request.jwt.claim.sub', uid::text, false)
$$;
grant execute on function public.t_fails(text, text), public.t_login(uuid) to authenticated;

-- Fixtures (as table owner, like a payment webhook using the service role).
insert into auth.users (id, email) values
  ('aaaaaaaa-0000-0000-0000-000000000001', 'alice@example.com'),
  ('bbbbbbbb-0000-0000-0000-000000000002', 'bob@example.com');
insert into public.user_subscriptions (id, user_id, plan_id) values
  ('a1000000-0000-0000-0000-000000000001', 'aaaaaaaa-0000-0000-0000-000000000001', 'basic'),
  ('a2000000-0000-0000-0000-000000000002', 'aaaaaaaa-0000-0000-0000-000000000001', 'founding'),
  ('b1000000-0000-0000-0000-000000000003', 'bbbbbbbb-0000-0000-0000-000000000002', 'standard');

do $$ begin
  assert (select count(*) from public.profiles) = 2, 'signup trigger should create profiles';
  assert (select count(*) from public.plan_content_items where plan_id='basic') = 3, 'basic: 2 ebooks + 1 course';
  assert (select count(*) from public.plan_content_items where plan_id='standard') = 5, 'standard: 3 ebooks + 2 courses';
  assert (select count(*) from public.plan_content_items where plan_id='founding') = 7, 'founding: 6 ebooks + masterclass';
end $$;

-- ===== Alice (authenticated) =====
set role authenticated;
select public.t_login('aaaaaaaa-0000-0000-0000-000000000001');

-- A user can never grant themselves a plan.
select public.t_fails($$insert into public.user_subscriptions (user_id, plan_id) values ('aaaaaaaa-0000-0000-0000-000000000001','founding')$$);

-- Basic project: wrong ARC rejected, correct ARC accepted.
select public.t_fails($$insert into public.book_projects (id,user_id,subscription_id,plan_id,title,arc_awareness,arc_resolution,arc_call_to_action)
  values ('11111111-0000-0000-0000-000000000001','aaaaaaaa-0000-0000-0000-000000000001','a1000000-0000-0000-0000-000000000001','basic','x',2,2,1)$$, 'fixed ARC');
insert into public.book_projects (id,user_id,subscription_id,plan_id,title,arc_awareness,arc_resolution,arc_call_to_action)
  values ('11111111-0000-0000-0000-000000000001','aaaaaaaa-0000-0000-0000-000000000001','a1000000-0000-0000-0000-000000000001','basic','My Book',1,3,1);

-- Cannot create a project on someone else's subscription.
select public.t_fails($$insert into public.book_projects (user_id,subscription_id,plan_id,title,arc_awareness,arc_resolution,arc_call_to_action)
  values ('aaaaaaaa-0000-0000-0000-000000000001','b1000000-0000-0000-0000-000000000003','standard','steal',2,3,2)$$);

-- Wishes: main (0) + 1 revision allowed on Basic; a 2nd revision is refused.
insert into public.outline_wishes (project_id, revision_number, wish_text) values ('11111111-0000-0000-0000-000000000001', 0, 'main wish');
insert into public.outline_wishes (project_id, revision_number, wish_text) values ('11111111-0000-0000-0000-000000000001', 1, 'revised wish');
select public.t_fails($$insert into public.outline_wishes (project_id, revision_number, wish_text) values ('11111111-0000-0000-0000-000000000001', 2, 'too many')$$, 'revised wish');

-- Chords + chapter limits (Basic = 5 chapters, A1 R3 C1).
insert into public.chords (id, project_id, key, position) values
  ('c1000000-0000-0000-0000-00000000000a','11111111-0000-0000-0000-000000000001','A',1),
  ('c1000000-0000-0000-0000-00000000000b','11111111-0000-0000-0000-000000000001','R',2),
  ('c1000000-0000-0000-0000-00000000000c','11111111-0000-0000-0000-000000000001','C',3);
insert into public.chapters (id, project_id, chord_id, number, title) values
  ('d1000000-0000-0000-0000-000000000001','11111111-0000-0000-0000-000000000001','c1000000-0000-0000-0000-00000000000a',1,'Ch1');
select public.t_fails($$insert into public.chapters (project_id, chord_id, number) values ('11111111-0000-0000-0000-000000000001','c1000000-0000-0000-0000-00000000000a',2)$$, 'limited to 1 chapter');
insert into public.chapters (project_id, chord_id, number) values
  ('11111111-0000-0000-0000-000000000001','c1000000-0000-0000-0000-00000000000b',2),
  ('11111111-0000-0000-0000-000000000001','c1000000-0000-0000-0000-00000000000b',3),
  ('11111111-0000-0000-0000-000000000001','c1000000-0000-0000-0000-00000000000b',4),
  ('11111111-0000-0000-0000-000000000001','c1000000-0000-0000-0000-00000000000c',5);
select public.t_fails($$insert into public.chapters (project_id, chord_id, number) values ('11111111-0000-0000-0000-000000000001','c1000000-0000-0000-0000-00000000000c',6)$$, 'allows 5 chapters');
do $$ begin assert (select count(*) from public.chapters) = 5, 'exactly 5 chapters on Basic'; end $$;

-- Syntax strings: SYA + ASA + YAA stored as structured rows; invalid rows rejected.
insert into public.chapter_syntax_strings (chapter_id, position, elements) values
  ('d1000000-0000-0000-0000-000000000001',1,'{S,Y,A}'),
  ('d1000000-0000-0000-0000-000000000001',2,'{A,S,A}'),
  ('d1000000-0000-0000-0000-000000000001',3,'{Y,A,A}');
select public.t_fails($$insert into public.chapter_syntax_strings (chapter_id, position, elements) values ('d1000000-0000-0000-0000-000000000001',4,'{S,X,A}')$$);
select public.t_fails($$insert into public.chapter_syntax_strings (chapter_id, position, elements) values ('d1000000-0000-0000-0000-000000000001',4,'{S,Y}')$$);

-- Narrative + advice strands hang off the same chapter.
insert into public.grand_advice_statements (chapter_id, position, statement) values ('d1000000-0000-0000-0000-000000000001',1,'advice');
insert into public.subheadings (id, chapter_id, position, sub_sentence) values ('e1000000-0000-0000-0000-000000000001','d1000000-0000-0000-0000-000000000001',1,'sub');
insert into public.say_points (id, subheading_id, position, micro_sentence) values ('f1000000-0000-0000-0000-000000000001','e1000000-0000-0000-0000-000000000001',1,'micro');
insert into public.say_components (say_point_id, position, element, content) values
  ('f1000000-0000-0000-0000-000000000001',1,'S','story'),('f1000000-0000-0000-0000-000000000001',2,'Y','evidence'),('f1000000-0000-0000-0000-000000000001',3,'A','advice');
select public.t_fails($$insert into public.say_components (say_point_id, position, element) values ('f1000000-0000-0000-0000-000000000001',4,'Z')$$);

-- Founding: customizable ARC (9 chapters).
insert into public.book_projects (id,user_id,subscription_id,plan_id,title,arc_awareness,arc_resolution,arc_call_to_action)
  values ('22222222-0000-0000-0000-000000000002','aaaaaaaa-0000-0000-0000-000000000001','a2000000-0000-0000-0000-000000000002','founding','Founder Book',2,4,3);
select public.t_fails($$insert into public.book_projects (user_id,subscription_id,plan_id,title,arc_awareness,arc_resolution,arc_call_to_action)
  values ('aaaaaaaa-0000-0000-0000-000000000001','a2000000-0000-0000-0000-000000000002','founding','bad total',3,4,3)$$, '9 chapters');
select public.t_fails($$insert into public.book_projects (user_id,subscription_id,plan_id,title,arc_awareness,arc_resolution,arc_call_to_action)
  values ('aaaaaaaa-0000-0000-0000-000000000001','a2000000-0000-0000-0000-000000000002','founding','empty chord',0,5,4)$$, 'at least one chapter');

-- ===== Bob must not see or touch Alice's data =====
select public.t_login('bbbbbbbb-0000-0000-0000-000000000002');
do $$ begin
  assert (select count(*) from public.book_projects) = 0, 'Bob sees no projects of Alice';
  assert (select count(*) from public.chapters) = 0, 'Bob sees no chapters of Alice';
  assert (select count(*) from public.say_components) = 0, 'Bob sees no components of Alice';
  assert (select count(*) from public.user_subscriptions) = 1, 'Bob sees only his own subscription';
  assert (select count(*) from public.profiles) = 1, 'Bob sees only his own profile';
end $$;
select public.t_fails($$insert into public.say_components (say_point_id, position, element) values ('f1000000-0000-0000-0000-000000000001',9,'S')$$);
select public.t_fails($$insert into public.chapters (project_id, chord_id, number) values ('11111111-0000-0000-0000-000000000001','c1000000-0000-0000-0000-00000000000c',9)$$);
update public.book_projects set title = 'hacked' where id = '11111111-0000-0000-0000-000000000001';
delete from public.book_projects where id = '11111111-0000-0000-0000-000000000001';

-- ===== Alice: data persisted, untouched, and cascades on delete =====
select public.t_login('aaaaaaaa-0000-0000-0000-000000000001');
do $$ begin
  assert (select title from public.book_projects where id = '11111111-0000-0000-0000-000000000001') = 'My Book', 'Bob could not modify/delete';
end $$;
delete from public.book_projects where id = '11111111-0000-0000-0000-000000000001';
do $$ begin
  assert (select count(*) from public.chapters where project_id = '11111111-0000-0000-0000-000000000001') = 0, 'chapters cascade';
  assert (select count(*) from public.say_components) = 0, 'components cascade';
end $$;

reset role;
select 'ALL SCHEMA TESTS PASSED' as result;
