-- SAYBOOK initial schema.
-- Hierarchy: book_projects -> chords -> chapters -> subheadings -> say_points -> say_components
-- Plan numbers below mirror src/lib/plans.ts (scripts/verify-core.mts checks they agree).
-- Run in the Supabase SQL editor or via `supabase db push`.

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------------
create or replace function public.set_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

-- ---------------------------------------------------------------------------
-- Plans (read-only reference data)
-- ---------------------------------------------------------------------------
create table public.plans (
  id                  text primary key check (id in ('basic','standard','founding')),
  name                text    not null,
  price_usd_cents     integer not null check (price_usd_cents > 0),
  revised_wishes      integer not null check (revised_wishes >= 0),
  chapter_count       integer not null check (chapter_count > 0),
  arc_awareness       integer not null check (arc_awareness >= 0),
  arc_resolution      integer not null check (arc_resolution >= 0),
  arc_call_to_action  integer not null check (arc_call_to_action >= 0),
  customizable_arc    boolean not null default false,
  seat_limit          integer check (seat_limit is null or seat_limit > 0),
  check (arc_awareness + arc_resolution + arc_call_to_action = chapter_count)
);

insert into public.plans
  (id, name, price_usd_cents, revised_wishes, chapter_count, arc_awareness, arc_resolution, arc_call_to_action, customizable_arc, seat_limit)
values
  ('basic', 'Basic', 5900, 1, 5, 1, 3, 1, false, null),
  ('standard', 'Standard', 7900, 2, 7, 2, 3, 2, false, null),
  ('founding', 'Founding Member', 19900, 3, 9, 3, 4, 2, true, 50);

-- Content catalog: slots only. The client has NOT supplied e-book, course or
-- masterclass content, so no bodies/URLs are invented. `asset_url` stays null
-- until the client provides material.
create table public.content_items (
  id          uuid primary key default gen_random_uuid(),
  slug        text not null unique,
  kind        text not null check (kind in ('ebook','mini_course','masterclass')),
  title       text not null,
  asset_url   text,
  sort_order  integer not null default 0
);

create table public.plan_content_items (
  plan_id          text not null references public.plans(id) on delete cascade,
  content_item_id  uuid not null references public.content_items(id) on delete cascade,
  primary key (plan_id, content_item_id)
);

-- E-book titles are exactly as written by the client. Mini-course titles were not
-- provided, so they are neutral numbered slots.
insert into public.content_items (slug, kind, title, sort_order) values
  ('ebook-say-point-theory',  'ebook', 'SAY Point Theory', 1),
  ('ebook-say-what-you-mean', 'ebook', 'SAY What You Mean', 2),
  ('ebook-just-say-it',       'ebook', 'Just SAY It', 3),
  ('ebook-say-point-writing', 'ebook', 'SAY Point Writing', 4),
  ('ebook-say-point-lattice', 'ebook', 'SAY Point Lattice', 5),
  ('ebook-say-it-with-style', 'ebook', 'SAY It With Style', 6),
  ('mini-course-1', 'mini_course', 'Mini Course 1', 1),
  ('mini-course-2', 'mini_course', 'Mini Course 2', 2),
  ('grand-masterclass', 'masterclass', 'Grand Masterclass', 1);

insert into public.plan_content_items (plan_id, content_item_id)
select p.plan_id, c.id from (values
  ('basic','ebook-say-point-theory'), ('basic','ebook-say-what-you-mean'), ('basic','mini-course-1'),
  ('standard','ebook-just-say-it'), ('standard','ebook-say-what-you-mean'), ('standard','ebook-say-point-theory'),
  ('standard','mini-course-1'), ('standard','mini-course-2'),
  ('founding','ebook-say-point-theory'), ('founding','ebook-say-point-writing'), ('founding','ebook-say-point-lattice'),
  ('founding','ebook-say-what-you-mean'), ('founding','ebook-say-it-with-style'), ('founding','ebook-just-say-it'),
  ('founding','grand-masterclass')
) as p(plan_id, slug)
join public.content_items c on c.slug = p.slug;

-- ---------------------------------------------------------------------------
-- Profiles & subscriptions
-- ---------------------------------------------------------------------------
create table public.profiles (
  id            uuid primary key references auth.users(id) on delete cascade,
  display_name  text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create trigger profiles_updated_at before update on public.profiles
  for each row execute function public.set_updated_at();

create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1)));
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Rows are written ONLY by trusted server code (payment webhook / admin script,
-- using the service-role key). Users can read their own but never grant themselves a plan.
create table public.user_subscriptions (
  id                 uuid primary key default gen_random_uuid(),
  user_id            uuid not null references public.profiles(id) on delete cascade,
  plan_id            text not null references public.plans(id),
  status             text not null default 'active' check (status in ('pending','active','cancelled')),
  payment_provider   text,       -- e.g. 'stripe' once the client confirms a provider
  provider_reference text,
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);
create index on public.user_subscriptions (user_id, status);
create trigger user_subscriptions_updated_at before update on public.user_subscriptions
  for each row execute function public.set_updated_at();

-- ---------------------------------------------------------------------------
-- Book projects and wishes
-- ---------------------------------------------------------------------------
create table public.book_projects (
  id                  uuid primary key default gen_random_uuid(),
  user_id             uuid not null references public.profiles(id) on delete cascade,
  subscription_id     uuid not null references public.user_subscriptions(id),
  plan_id             text not null references public.plans(id),
  title               text not null check (char_length(title) between 1 and 200),
  description         text not null default '',
  audience            text not null default '',
  theme               text not null default '',
  status              text not null default 'draft' check (status in ('draft','in_progress','complete')),
  -- Chapters per Chord for THIS project (== plan default unless plan.customizable_arc).
  arc_awareness       integer not null,
  arc_resolution      integer not null,
  arc_call_to_action  integer not null,
  -- Flexible, plan-derived display configuration, e.g. {"label":"3×3","dimensions":[3,3]}.
  matrix_config       jsonb not null default '{}'::jsonb,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  check (arc_awareness >= 0 and arc_resolution >= 0 and arc_call_to_action >= 0)
);
create index on public.book_projects (user_id, updated_at desc);
create trigger book_projects_updated_at before update on public.book_projects
  for each row execute function public.set_updated_at();

-- A project's ARC must fit its plan, and the plan must belong to the subscription.
create function public.validate_book_project() returns trigger
language plpgsql as $$
declare
  p public.plans;
  s public.user_subscriptions;
begin
  select * into s from public.user_subscriptions where id = new.subscription_id;
  if s.id is null or s.user_id <> new.user_id or s.status <> 'active' then
    raise exception 'An active subscription owned by the user is required to create a project.';
  end if;
  if s.plan_id <> new.plan_id then
    raise exception 'Project plan must match the subscription plan.';
  end if;
  select * into p from public.plans where id = new.plan_id;
  if new.arc_awareness + new.arc_resolution + new.arc_call_to_action <> p.chapter_count then
    raise exception 'ARC must total % chapters for the % plan.', p.chapter_count, p.name;
  end if;
  if not p.customizable_arc and (
       new.arc_awareness <> p.arc_awareness
    or new.arc_resolution <> p.arc_resolution
    or new.arc_call_to_action <> p.arc_call_to_action) then
    raise exception 'The % plan uses a fixed ARC.', p.name;
  end if;
  if p.customizable_arc and least(new.arc_awareness, new.arc_resolution, new.arc_call_to_action) < 1 then
    raise exception 'Each Chord needs at least one chapter.';  -- recommendation, see docs
  end if;
  return new;
end $$;
create trigger book_projects_validate before insert or update of subscription_id, plan_id, arc_awareness, arc_resolution, arc_call_to_action on public.book_projects
  for each row execute function public.validate_book_project();

-- Main Outline Wish (revision_number 0) and its revisions (1..plan.revised_wishes).
create table public.outline_wishes (
  id               uuid primary key default gen_random_uuid(),
  project_id       uuid not null references public.book_projects(id) on delete cascade,
  revision_number  integer not null check (revision_number >= 0),
  wish_text        text not null check (char_length(wish_text) > 0),
  created_at       timestamptz not null default now(),
  unique (project_id, revision_number)
);

create function public.enforce_wish_limit() returns trigger
language plpgsql as $$
declare
  allowed integer;
begin
  select p.revised_wishes into allowed
  from public.book_projects b join public.plans p on p.id = b.plan_id
  where b.id = new.project_id;
  if new.revision_number > allowed then
    raise exception 'This plan allows % revised wish(es).', allowed;
  end if;
  return new;
end $$;
create trigger outline_wishes_limit before insert on public.outline_wishes
  for each row execute function public.enforce_wish_limit();

-- ---------------------------------------------------------------------------
-- DHM structure
-- ---------------------------------------------------------------------------
create table public.chords (
  id          uuid primary key default gen_random_uuid(),
  project_id  uuid not null references public.book_projects(id) on delete cascade,
  key         text not null check (key in ('A','R','C')),
  position    smallint not null check (position between 1 and 3),
  unique (project_id, key),
  unique (project_id, position)
);

create table public.chapters (
  id            uuid primary key default gen_random_uuid(),
  project_id    uuid not null references public.book_projects(id) on delete cascade,
  chord_id      uuid not null references public.chords(id) on delete cascade,
  number        integer not null check (number >= 1),
  title         text not null default '',
  main_sentence text not null default '',   -- Story of Thesis (Main Sentence)
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (project_id, number) deferrable initially deferred  -- allows reordering inside a transaction
);
create index on public.chapters (chord_id);
create trigger chapters_updated_at before update on public.chapters
  for each row execute function public.set_updated_at();

-- A chapter must belong to a chord of the same project, and respect plan + ARC limits.
create function public.enforce_chapter_limits() returns trigger
language plpgsql as $$
declare
  b public.book_projects;
  p public.plans;
  chord_key text;
  chord_project uuid;
  chord_allowed integer;
  chord_count integer;
  total_count integer;
begin
  select * into b from public.book_projects where id = new.project_id;
  select * into p from public.plans where id = b.plan_id;
  select key, project_id into chord_key, chord_project from public.chords where id = new.chord_id;
  if chord_project is distinct from new.project_id then
    raise exception 'Chord does not belong to this project.';
  end if;

  chord_allowed := case chord_key
    when 'A' then b.arc_awareness when 'R' then b.arc_resolution else b.arc_call_to_action end;
  select count(*) into chord_count from public.chapters
    where chord_id = new.chord_id and id <> new.id;
  select count(*) into total_count from public.chapters
    where project_id = new.project_id and id <> new.id;

  if total_count + 1 > p.chapter_count then
    raise exception 'The % plan allows % chapters.', p.name, p.chapter_count;
  end if;
  if chord_count + 1 > chord_allowed then
    raise exception 'This Chord is limited to % chapter(s) by the ARC.', chord_allowed;
  end if;
  return new;
end $$;
create trigger chapters_limits before insert or update of chord_id on public.chapters
  for each row execute function public.enforce_chapter_limits();

-- Chapter syntax: ordered SAY strings, each exactly three S/Y/A elements.
-- e.g. SYA + ASA + YAA = three rows with elements {S,Y,A}, {A,S,A}, {Y,A,A}.
create table public.chapter_syntax_strings (
  id          uuid primary key default gen_random_uuid(),
  chapter_id  uuid not null references public.chapters(id) on delete cascade,
  position    smallint not null check (position >= 1),
  elements    text[] not null,
  unique (chapter_id, position) deferrable initially deferred,
  check (cardinality(elements) = 3 and elements <@ array['S','Y','A'])
);

-- Grand Advice: Main Advice Statements per chapter.
create table public.grand_advice_statements (
  id          uuid primary key default gen_random_uuid(),
  chapter_id  uuid not null references public.chapters(id) on delete cascade,
  position    smallint not null check (position >= 1),
  statement   text not null default '',
  unique (chapter_id, position) deferrable initially deferred
);

create table public.subheadings (
  id            uuid primary key default gen_random_uuid(),
  chapter_id    uuid not null references public.chapters(id) on delete cascade,
  position      smallint not null check (position >= 1),
  sub_sentence  text not null default '',
  unique (chapter_id, position) deferrable initially deferred
);

create table public.say_points (
  id              uuid primary key default gen_random_uuid(),
  subheading_id   uuid not null references public.subheadings(id) on delete cascade,
  position        smallint not null check (position >= 1),
  micro_sentence  text not null default '',
  unique (subheading_id, position) deferrable initially deferred
);

-- One table for the Story / Yielded Evidence / Advice components of a SAY point.
-- (The client document uses both single-element points and mixed S+Y+A points,
--  so a point holds an ordered list of typed components.)
create table public.say_components (
  id            uuid primary key default gen_random_uuid(),
  say_point_id  uuid not null references public.say_points(id) on delete cascade,
  position      smallint not null check (position >= 1),
  element       text not null check (element in ('S','Y','A')),
  content       text not null default '',
  unique (say_point_id, position) deferrable initially deferred
);

create table public.exports (
  id          uuid primary key default gen_random_uuid(),
  project_id  uuid not null references public.book_projects(id) on delete cascade,
  user_id     uuid not null references public.profiles(id) on delete cascade,
  format      text not null default 'pdf' check (format in ('pdf')),
  created_at  timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- Row Level Security
-- ---------------------------------------------------------------------------
-- Ownership helpers run as definer so policies don't recurse through RLS.
create function public.owns_project(pid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.book_projects where id = pid and user_id = auth.uid())
$$;
create function public.owns_chapter(cid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.chapters c join public.book_projects b on b.id = c.project_id
                 where c.id = cid and b.user_id = auth.uid())
$$;
create function public.owns_subheading(sid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.subheadings s join public.chapters c on c.id = s.chapter_id
                 join public.book_projects b on b.id = c.project_id
                 where s.id = sid and b.user_id = auth.uid())
$$;
create function public.owns_say_point(pid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.say_points p join public.subheadings s on s.id = p.subheading_id
                 join public.chapters c on c.id = s.chapter_id
                 join public.book_projects b on b.id = c.project_id
                 where p.id = pid and b.user_id = auth.uid())
$$;

alter table public.plans                    enable row level security;
alter table public.content_items            enable row level security;
alter table public.plan_content_items       enable row level security;
alter table public.profiles                 enable row level security;
alter table public.user_subscriptions       enable row level security;
alter table public.book_projects            enable row level security;
alter table public.outline_wishes           enable row level security;
alter table public.chords                   enable row level security;
alter table public.chapters                 enable row level security;
alter table public.chapter_syntax_strings   enable row level security;
alter table public.grand_advice_statements  enable row level security;
alter table public.subheadings              enable row level security;
alter table public.say_points               enable row level security;
alter table public.say_components           enable row level security;
alter table public.exports                  enable row level security;

-- Reference data: readable by anyone (the marketing pricing section needs it).
create policy "plans readable" on public.plans for select using (true);
create policy "content_items readable" on public.content_items for select to authenticated using (true);
create policy "plan_content_items readable" on public.plan_content_items for select using (true);

create policy "own profile read"   on public.profiles for select using (id = auth.uid());
create policy "own profile update" on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());

-- Subscriptions: read-only for users. No insert/update/delete policy => service role only.
create policy "own subscriptions read" on public.user_subscriptions for select using (user_id = auth.uid());

create policy "own projects select" on public.book_projects for select using (user_id = auth.uid());
create policy "own projects insert" on public.book_projects for insert with check (user_id = auth.uid());
create policy "own projects update" on public.book_projects for update using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "own projects delete" on public.book_projects for delete using (user_id = auth.uid());

create policy "own wishes all" on public.outline_wishes for all
  using (public.owns_project(project_id)) with check (public.owns_project(project_id));
create policy "own chords all" on public.chords for all
  using (public.owns_project(project_id)) with check (public.owns_project(project_id));
create policy "own chapters all" on public.chapters for all
  using (public.owns_project(project_id)) with check (public.owns_project(project_id));
create policy "own exports all" on public.exports for all
  using (user_id = auth.uid() and public.owns_project(project_id))
  with check (user_id = auth.uid() and public.owns_project(project_id));

create policy "own syntax all" on public.chapter_syntax_strings for all
  using (public.owns_chapter(chapter_id)) with check (public.owns_chapter(chapter_id));
create policy "own advice all" on public.grand_advice_statements for all
  using (public.owns_chapter(chapter_id)) with check (public.owns_chapter(chapter_id));
create policy "own subheadings all" on public.subheadings for all
  using (public.owns_chapter(chapter_id)) with check (public.owns_chapter(chapter_id));
create policy "own say_points all" on public.say_points for all
  using (public.owns_subheading(subheading_id)) with check (public.owns_subheading(subheading_id));
create policy "own say_components all" on public.say_components for all
  using (public.owns_say_point(say_point_id)) with check (public.owns_say_point(say_point_id));
