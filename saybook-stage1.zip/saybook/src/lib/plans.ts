/**
 * SAYBOOK plan configuration — the single source of truth for plan limits.
 *
 * Source: client document "SAYBOOK App MVP" (three plans on the sales page).
 * Nothing else in the codebase should hardcode chapter counts, revised-wish
 * limits, ARC distributions or prices. Read them from here.
 *
 * Open client questions that affect this file are listed in docs/STAGE1_PLAN.md
 * (matrix meaning, customizable-ARC rules, upgrade rules).
 */

export type PlanId = "basic" | "standard" | "founding";

/** The three ARC stages. Each stage is realized as one Chord. */
export type ChordKey = "A" | "R" | "C";

export const CHORD_ORDER: readonly ChordKey[] = ["A", "R", "C"] as const;

/** Chapters per Chord, e.g. { A: 1, R: 3, C: 1 } is the "1-3-1" ARC. */
export type ArcDistribution = Record<ChordKey, number>;

export interface ChordDefinition {
  key: ChordKey;
  /** "Chord 1", "Chord 2", "Chord 3" in the client document. */
  chordNumber: 1 | 2 | 3;
  name: "Awareness" | "Resolution" | "Call to Action";
  /** Client wording: "External/Contextual" etc. */
  focus: string;
  /** Client wording from the ARC-Problem-SOT table. */
  problem: string;
  /** Client wording: Seed -> Cultivation -> Harvest growth phase. */
  phase: "Seed" | "Cultivation" | "Harvest";
  /** One-line purpose, paraphrased from the client's ARC definitions. */
  purpose: string;
}

export const CHORDS: Readonly<Record<ChordKey, ChordDefinition>> = {
  A: {
    key: "A",
    chordNumber: 1,
    name: "Awareness",
    focus: "External / Contextual",
    problem: "The Contextual Problem",
    phase: "Seed",
    purpose:
      "Establish what has changed and why the reader must recognize the problem.",
  },
  R: {
    key: "R",
    chordNumber: 2,
    name: "Resolution",
    focus: "Mechanical / Systemic",
    problem: "The Methodological Problem",
    phase: "Cultivation",
    purpose: "Present the framework or method that resolves the problem.",
  },
  C: {
    key: "C",
    chordNumber: 3,
    name: "Call to Action",
    focus: "Identity / Essential",
    problem: "The Operational Problem",
    phase: "Harvest",
    purpose:
      "Show the actions, behaviors and capabilities required to implement the solution.",
  },
};

export interface PlanConfig {
  id: PlanId;
  name: string;
  /** Whole US dollars, as listed by the client. */
  priceUsd: number;
  /** Revisions of the Main Outline Wish allowed in addition to the main wish. */
  revisedWishes: number;
  /** Total chapters; always equals the sum of `arc`. */
  chapterCount: number;
  /** Default chapters per Chord. */
  arc: ArcDistribution;
  /** Founding member only: the author may redistribute chapters across Chords. */
  customizableArc: boolean;
  /**
   * The client lists "3*3 matrix" / "4*3 matrix" without defining it.
   * Kept as an opaque, configurable pair until the client confirms the meaning.
   */
  matrix: { label: string; dimensions: readonly [number, number] };
  editablePdf: boolean;
  /** Titles exactly as written by the client. Content is NOT provided yet. */
  ebooks: readonly string[];
  miniCourses: number;
  grandMasterclass: boolean;
  /** Founding member extras. */
  lifetimeDiscount: boolean;
  featureSuggestionsPerFounder: number;
  /** Maximum number of purchasers of this plan, if limited. */
  seatLimit: number | null;
}

export const PLANS: Readonly<Record<PlanId, PlanConfig>> = {
  basic: {
    id: "basic",
    name: "Basic",
    priceUsd: 59,
    revisedWishes: 1,
    chapterCount: 5,
    arc: { A: 1, R: 3, C: 1 },
    customizableArc: false,
    matrix: { label: "3×3", dimensions: [3, 3] },
    editablePdf: true,
    ebooks: ["SAY Point Theory", "SAY What You Mean"],
    miniCourses: 1,
    grandMasterclass: false,
    lifetimeDiscount: false,
    featureSuggestionsPerFounder: 0,
    seatLimit: null,
  },
  standard: {
    id: "standard",
    name: "Standard",
    priceUsd: 79,
    revisedWishes: 2,
    chapterCount: 7,
    arc: { A: 2, R: 3, C: 2 },
    customizableArc: false,
    matrix: { label: "3×3", dimensions: [3, 3] },
    editablePdf: true,
    ebooks: ["Just SAY It", "SAY What You Mean", "SAY Point Theory"],
    miniCourses: 2,
    grandMasterclass: false,
    lifetimeDiscount: false,
    featureSuggestionsPerFounder: 0,
    seatLimit: null,
  },
  founding: {
    id: "founding",
    name: "Founding Member",
    priceUsd: 199,
    revisedWishes: 3,
    chapterCount: 9,
    arc: { A: 3, R: 4, C: 2 },
    customizableArc: true,
    matrix: { label: "4×3", dimensions: [4, 3] },
    editablePdf: true,
    ebooks: [
      "SAY Point Theory",
      "SAY Point Writing",
      "SAY Point Lattice",
      "SAY What You Mean",
      "SAY It With Style",
      "Just SAY It",
    ],
    miniCourses: 0, // not listed for this plan in the client document
    grandMasterclass: true,
    lifetimeDiscount: true,
    featureSuggestionsPerFounder: 3,
    seatLimit: 50,
  },
};

export const PLAN_IDS = Object.keys(PLANS) as PlanId[];

export function getPlan(id: string): PlanConfig {
  const plan = (PLANS as Record<string, PlanConfig | undefined>)[id];
  if (!plan) throw new Error(`Unknown plan id: ${id}`);
  return plan;
}

export function sumArc(arc: ArcDistribution): number {
  return CHORD_ORDER.reduce((total, key) => total + arc[key], 0);
}

export type ArcValidationResult =
  | { ok: true }
  | { ok: false; reason: string };

/**
 * Validate a (possibly customized) ARC distribution against a plan.
 *
 * Rules:
 *  - Non-customizable plans must use their default distribution.
 *  - Customizable plans must keep the plan's total chapter count.
 *  - RECOMMENDATION (not a client rule — see open questions): every Chord
 *    keeps at least 1 chapter, otherwise the ARC is no longer A -> R -> C.
 */
export function validateArc(
  plan: PlanConfig,
  arc: ArcDistribution,
): ArcValidationResult {
  for (const key of CHORD_ORDER) {
    const n = arc[key];
    if (!Number.isInteger(n) || n < 0) {
      return { ok: false, reason: `Chord ${key} must be a whole number.` };
    }
  }
  if (!plan.customizableArc) {
    const same = CHORD_ORDER.every((k) => arc[k] === plan.arc[k]);
    return same
      ? { ok: true }
      : {
          ok: false,
          reason: `The ${plan.name} plan uses a fixed ARC of ${formatArc(plan.arc)}.`,
        };
  }
  if (sumArc(arc) !== plan.chapterCount) {
    return {
      ok: false,
      reason: `The ${plan.name} plan has exactly ${plan.chapterCount} chapters; this ARC has ${sumArc(arc)}.`,
    };
  }
  const empty = CHORD_ORDER.find((k) => arc[k] < 1);
  if (empty) {
    return {
      ok: false,
      reason: `Each Chord needs at least one chapter (${CHORDS[empty].name} has none).`,
    };
  }
  return { ok: true };
}

/** "1-3-1" style label. */
export function formatArc(arc: ArcDistribution): string {
  return CHORD_ORDER.map((k) => arc[k]).join("-");
}

export function canUseRevisedWish(plan: PlanConfig, revisionsUsed: number): boolean {
  return revisionsUsed < plan.revisedWishes;
}

export function revisedWishesRemaining(plan: PlanConfig, revisionsUsed: number): number {
  return Math.max(0, plan.revisedWishes - revisionsUsed);
}
