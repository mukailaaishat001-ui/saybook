/**
 * DHM domain model (Double Helix Map).
 *
 * Hierarchy from the client document, mirrored in the database:
 *
 *   Book Project
 *     -> Chord (A / R / C)
 *       -> Chapter           (Main Sentence = Story of Thesis; Syntax; Main Advice Statements)
 *         -> Subheading      (Sub-Sentence)
 *           -> SAY Point     (Micro-Sentence)
 *             -> Components  (Story / Yielded Evidence / Advice)
 *
 * Grand Narrative = the chain of Main Sentences / Sub-Sentences / Micro-Sentences.
 * Grand Advice    = the Main Advice Statements (and Advice components).
 * Both live on the same Chapter so they can never drift apart structurally.
 */
import type { ChordKey } from "../plans.ts";
import type { ChapterSyntax, SayElement } from "./syntax.ts";

export interface SayComponent {
  id: string;
  element: SayElement;
  /** Outline-level note. NOT required to be a full 200–300 word passage. */
  content: string;
}

export interface SayPoint {
  id: string;
  /** Micro-Sentence: the SOT sentence for this point. */
  microSentence: string;
  components: SayComponent[];
}

export interface Subheading {
  id: string;
  /** Sub-Sentence supporting the chapter's Main Sentence. */
  subSentence: string;
  sayPoints: SayPoint[];
}

export interface AdviceStatement {
  id: string;
  statement: string;
}

export interface Chapter {
  id: string;
  /** Continuous across Chords: 1..N. */
  number: number;
  title: string;
  /** Story of Thesis, Main Sentence. */
  mainSentence: string;
  syntax: ChapterSyntax;
  subheadings: Subheading[];
  /** Grand Advice: Main Advice Statements for this chapter. */
  mainAdvice: AdviceStatement[];
}

export interface Chord {
  key: ChordKey;
  chapters: Chapter[];
}

export interface Dhm {
  chords: Chord[];
}

export function allChapters(dhm: Dhm): Chapter[] {
  return dhm.chords.flatMap((c) => c.chapters);
}
