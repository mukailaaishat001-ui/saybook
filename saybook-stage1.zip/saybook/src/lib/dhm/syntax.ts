/**
 * SAY syntax — structured representation of the client's "Chapter (String) Syntax".
 *
 * Client examples: SYA, ASA, YAA, and Chapter 1's "SYA+ ASA+ YAA".
 * S = Story, Y = Yielded Evidence, A = Advice.
 *
 * A chapter's syntax is an ordered list of three-element strings. It is stored
 * and edited as data (arrays of elements), never as a free-text blob.
 *
 * Assumption (flagged in docs/STAGE1_PLAN.md): every string has exactly three
 * elements, because all client examples do. Change STRING_LENGTH if the client
 * confirms longer or shorter strings.
 */

export type SayElement = "S" | "Y" | "A";

export const SAY_ELEMENTS: readonly SayElement[] = ["S", "Y", "A"] as const;

export const SAY_ELEMENT_NAMES: Readonly<Record<SayElement, string>> = {
  S: "Story",
  Y: "Yielded Evidence",
  A: "Advice",
};

export const STRING_LENGTH = 3;

/** One SAY string such as SYA. */
export type SayString = readonly SayElement[];

/** A chapter's full syntax, e.g. SYA + ASA + YAA. */
export type ChapterSyntax = readonly SayString[];

export function isSayElement(value: string): value is SayElement {
  return value === "S" || value === "Y" || value === "A";
}

export type ParseResult =
  | { ok: true; syntax: ChapterSyntax }
  | { ok: false; error: string };

/**
 * Parse text like "SYA+ ASA+ YAA" (the client's own spacing is irregular).
 * Case-insensitive. Whitespace around "+" is ignored.
 */
export function parseSyntax(input: string): ParseResult {
  const cleaned = input.trim().toUpperCase();
  if (cleaned === "") return { ok: false, error: "Enter at least one SAY string, e.g. SYA." };

  const parts = cleaned.split("+").map((p) => p.trim());
  const strings: SayElement[][] = [];

  for (const part of parts) {
    if (part === "") return { ok: false, error: "Remove the empty segment between '+' signs." };
    if (part.length !== STRING_LENGTH) {
      return {
        ok: false,
        error: `"${part}" must have exactly ${STRING_LENGTH} letters from S, Y and A.`,
      };
    }
    const elements: SayElement[] = [];
    for (const ch of part) {
      if (!isSayElement(ch)) {
        return { ok: false, error: `"${ch}" in "${part}" is not S, Y or A.` };
      }
      elements.push(ch);
    }
    strings.push(elements);
  }
  return { ok: true, syntax: strings };
}

/** Canonical display text: "SYA + ASA + YAA". */
export function formatSyntax(syntax: ChapterSyntax): string {
  return syntax.map((s) => s.join("")).join(" + ");
}

/** Stable key for comparing syntaxes between chapters. */
export function syntaxKey(syntax: ChapterSyntax): string {
  return syntax.map((s) => s.join("")).join("+");
}

/**
 * Plain-language description derived from the letters, so it works for any
 * valid string rather than only the three the client happened to name.
 * Example: SYA -> "Story, then Yielded Evidence, then Advice".
 */
export function describeString(string: SayString): string {
  return string.map((e) => SAY_ELEMENT_NAMES[e]).join(", then ");
}

/** The element a string is "led by" (first element). */
export function leadElement(string: SayString): SayElement {
  const first = string[0];
  if (!first) throw new Error("Empty SAY string");
  return first;
}

/** Total number of element slots in a syntax (e.g. SYA+ASA+YAA = 9). */
export function slotCount(syntax: ChapterSyntax): number {
  return syntax.reduce((n, s) => n + s.length, 0);
}
