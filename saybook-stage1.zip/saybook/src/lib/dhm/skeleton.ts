/**
 * Builds an empty DHM skeleton from a plan (and an optional customized ARC).
 * Chapter counts always come from plan configuration — never hardcoded here.
 */
import {
  CHORD_ORDER,
  getPlan,
  validateArc,
  type ArcDistribution,
  type PlanConfig,
  type PlanId,
} from "../plans.ts";
import type { Chapter, Chord, Dhm } from "./types.ts";

export type IdFactory = () => string;

const defaultId: IdFactory = () => globalThis.crypto.randomUUID();

export function createEmptyChapter(number: number, newId: IdFactory = defaultId): Chapter {
  return {
    id: newId(),
    number,
    title: "",
    mainSentence: "",
    syntax: [],
    subheadings: [],
    mainAdvice: [],
  };
}

/**
 * @throws if `arc` is not valid for the plan (e.g. customizing a Basic plan).
 */
export function createSkeleton(
  planOrId: PlanConfig | PlanId,
  arc?: ArcDistribution,
  newId: IdFactory = defaultId,
): Dhm {
  const plan = typeof planOrId === "string" ? getPlan(planOrId) : planOrId;
  const distribution = arc ?? plan.arc;

  const check = validateArc(plan, distribution);
  if (!check.ok) throw new Error(check.reason);

  let nextNumber = 1;
  const chords: Chord[] = CHORD_ORDER.map((key) => ({
    key,
    chapters: Array.from({ length: distribution[key] }, () =>
      createEmptyChapter(nextNumber++, newId),
    ),
  }));
  return { chords };
}
