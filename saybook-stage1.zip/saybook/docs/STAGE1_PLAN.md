# SAYBOOK — Stage 1: Requirements, Architecture and Plan

Source of truth: *SAYBOOK App MVP.docx* (client). Everything marked **Client** comes from that document.
Everything marked **Recommendation** is my proposal and is reversible.

---

## 1. Understanding of the product

SAYBOOK is a nonfiction **book-architecture** tool. Authors design the logical skeleton of a book before writing it. The client's own metaphor: *Structural Design* (the "Book Net") is separated from *Content Execution* ("pouring the concrete").

The core product is the **Double Helix Map (DHM)** — two strands that must grow together:

| Strand | Client term | What it holds |
|---|---|---|
| Grand Narrative | Story of Thesis (SOT) | The argument: one Main Sentence per chapter → Sub-Sentences → Micro-Sentences |
| Grand Advice | Main Advice Statements | The instruction/capability that matches each chapter's argument |

The DHM is also a **diagnostic**: gaps, repeated syntax, ARC drift, and a broken sentence chain show whether a book is structurally sound. The client is explicit that the MVP is *only* a working DHM ("a type of book outline generator"). It is not a manuscript editor or generic AI writer.

## 2. The DHM methodology as software behaviour

| Client concept | Software behaviour |
|---|---|
| **ARC** (Awareness → Resolution → Call to Action) | Three Chords, always in this order. Colour-coded throughout. |
| **Chord** (Part 1/2/3) | A group of chapters. Size per Chord comes from the plan (`arc`), never hardcoded. |
| **Chapter** | Number (continuous), title, **Main Sentence** (SOT), syntax, subheadings, **Main Advice Statements**. |
| **SOT hierarchy** | Main Sentence → Sub-Sentence (per subheading) → Micro-Sentence (per SAY point). |
| **SAY point / SAY module** | A structural slot, *not* forced prose. Holds a Micro-Sentence plus optional Story / Yielded Evidence / Advice notes. The 200–300 word figure is the future manuscript size, not an outline requirement. |
| **Chapter (String) Syntax** | Ordered list of 3-element strings (SYA, ASA, YAA…). Stored as arrays, validated, editable per chapter. `SYA + ASA + YAA` is Chapter 1's *example* only. |
| **SOT chain review** | One view that lists all Main Sentences in order as continuous prose (the client's "Sentencing Chain"), plus drill-down to Sub/Micro sentences. |
| **SAY Audit** | Rule-based checks (below). |
| **Matrix** | Plan-configured grid (3×3 / 4×3) — meaning needs client confirmation (Q3). |
| **Editable PDF** | Dedicated document layout with fillable fields for manual outlining. |

### SAY Audit — what is automatic and what is honest

| Client check | MVP implementation | Limits |
|---|---|---|
| Gaps in the Helix | Chapter has a Main Sentence but no Main Advice Statement (and vice-versa) | Fully rule-based |
| Syntax Clashes | Same normalized syntax in consecutive/most chapters; a chapter that uses one string repeated (e.g. SYA+SYA+SYA) | Fully rule-based |
| Missing SAY elements | A syntax slot, or a SAY point, lacks its Story / Evidence / Advice | Fully rule-based |
| Broken SOT chain | Flags *missing* links (empty sentences); shows the chain for the author to judge | Cannot judge logical coherence — UI wording must say "check", not "verdict" |
| ARC misalignment | Author-assigned ARC tag per chapter vs Chord; surfaces for review | Cannot read meaning without AI. Also see doc inconsistency #6 |

The audit never claims to evaluate argument quality; it reports completeness and structure.

## 3. Proposed architecture

- **Next.js (App Router) + React + strict TypeScript + Tailwind**, deployed on Vercel.
- **Supabase**: Postgres, Auth (email/password + password recovery), RLS on every table.
- **Server-first data flow**: Server Components read; **Server Actions** write, each validated with the same **zod** schema used by the client form. `@supabase/ssr` for cookie sessions. Service-role key only in server-only modules (webhooks / admin).
- **Pure domain layer** (`src/lib/plans.ts`, `src/lib/dhm/*`): framework-free, unit-testable — plan limits, skeleton generation, syntax parsing, audit rules, SOT chain. UI and DB layers call it; they don't re-implement it. *(Built and verified in this stage.)*
- **Editing model**: field-level autosave (debounced) with a visible `Saved / Saving / Unsaved / Error` indicator, an unsaved-changes guard on navigation, and explicit Save. Reordering uses accessible up/down controls first (no drag-and-drop dependency).
- **PDF export**: `pdf-lib` — server route that draws a purpose-built layout with real AcroForm text fields (works on Vercel without a headless browser). *Recommendation.*
- **Payments**: architecture only — `user_subscriptions` is written solely by trusted server code. Stripe is the likely provider but is unconfirmed (Q1).
- **New dependencies (kept minimal)**: `@supabase/supabase-js`, `@supabase/ssr`, `zod`, `lucide-react`, `pdf-lib`. Nothing else until needed.

## 4. Recommended folder structure

```
saybook/
├─ docs/                       STAGE1_PLAN.md, later: DEPLOYMENT.md
├─ supabase/
│  ├─ migrations/0001_init.sql          ✅ built, tested
│  └─ tests/                            ✅ local schema tests
├─ scripts/verify-core.mts              ✅ domain checks
├─ src/
│  ├─ app/
│  │  ├─ (marketing)/page.tsx, pricing anchors, layout
│  │  ├─ (auth)/login, register, forgot-password, reset-password
│  │  ├─ (app)/dashboard, projects/new, projects/[id]/(map|chain|audit|export|wish), account
│  │  └─ api/projects/[id]/export/route.ts, api/webhooks/payments/route.ts (later)
│  ├─ components/ ui/ marketing/ dhm/ (ChordColumn, ChapterRow, HelixStrand, SayPointEditor, SyntaxPicker, SaveStatus…)
│  ├─ lib/
│  │  ├─ plans.ts                       ✅
│  │  ├─ dhm/ types.ts syntax.ts skeleton.ts ✅  · audit.ts, chain.ts (Stage 5)
│  │  ├─ supabase/ client.ts server.ts admin.ts (server-only)
│  │  ├─ validation/ zod schemas
│  │  └─ pdf/ layout + fields
│  └─ middleware.ts                     session refresh + route protection
├─ .env.example · README.md
```

## 5. Database schema (implemented in `supabase/migrations/0001_init.sql`)

```
plans ──< plan_content_items >── content_items          (ebook / mini_course / masterclass slots; no content invented)
profiles (auth.users) ──< user_subscriptions >── plans   (written by service role only)
profiles ──< book_projects (plan_id, ARC counts, matrix_config jsonb)
book_projects ──< outline_wishes (revision 0 = Main Outline Wish, 1..n = revised wishes)
book_projects ──< chords (A/R/C) ──< chapters (number, title, main_sentence)
chapters ──< chapter_syntax_strings (elements text[3] ⊂ {S,Y,A})
chapters ──< grand_advice_statements
chapters ──< subheadings (sub_sentence) ──< say_points (micro_sentence) ──< say_components (S|Y|A + content)
book_projects ──< exports
```

Enforced **in the database**, not just the UI: ARC must match the plan (fixed unless customizable, total = plan chapters, ≥1 per Chord on founding); chapter totals and per-Chord caps; revised-wish limit; syntax strings are exactly 3 of S/Y/A; projects require an active subscription the user owns; RLS isolates every row by owner. Tested against Postgres 16 (see Verification).

Design choices to flag: one `say_components` table with an `element` column instead of three tables (the client uses both single-element and mixed points); matrix lives in `jsonb` because its meaning is unconfirmed; `project_id` is not duplicated on lower tables — ownership is checked through small `security definer` helper functions.

## 6. Plan configuration (`src/lib/plans.ts`, matches Client)

| | Basic | Standard | Founding Member |
|---|---|---|---|
| Price | $59 | $79 | $199 |
| Chapters | 5 | 7 | 9 |
| ARC (A-R-C) | 1-3-1 | 2-3-2 | 3-4-2 (customizable) |
| Revised wishes | 1 | 2 | 3 |
| Matrix | 3×3 | 3×3 | 4×3 |
| Editable PDF | ✓ | ✓ | ✓ |
| E-books | 2 | 3 | 6 |
| Mini-courses | 1 | 2 | *not listed* (stored as 0) |
| Grand Masterclass | — | — | ✓ |
| Extras | — | — | Lifetime discount · 3 feature suggestions · 50 seats |

## 7. Page-by-page

**Public:** `/` (nav, hero, product intro, DHM, Grand Narrative vs Advice, ARC, SAY, how it works, benefits, pricing with the three real plans, FAQ, final CTA, footer; demo-video and slides slots left empty until the client provides them). **Auth:** `/login`, `/register`, `/forgot-password`, `/reset-password`. **App:** `/dashboard` (projects, status, plan, empty state, "Start a DHM"), `/projects/new` (title, Main Outline Wish, description, audience, theme — client terms preserved; no extra mandatory fields), `/projects/[id]` **DHM workspace** (three-Chord map, chapter drawer: Main Sentence, syntax, subheadings, SAY points, advice), `/chain` (SOT review), `/audit` (SAY Audit), `/wish` (Main Outline Wish + revisions), `/export` (PDF), `/account` (plan, entitlements with content slots, sign-out, delete).

## 8. Roadmap

| Stage | Scope | Status |
|---|---|---|
| 1 | Document analysis, plan, domain core, schema | **Done** (this document) |
| 2 | Next.js scaffold, design system, layout, Supabase wiring | **Blocked here** — npm registry is denied by this sandbox's network policy |
| 3 | Marketing site + real pricing | next |
| 4 | Auth + dashboard + project creation | |
| 5 | **DHM workspace, SOT chain, SAY Audit** (highest priority) | |
| 6 | Persistence + PDF export | |
| 7 | Entitlements, subscription plumbing (payments after Q1/Q2) | |
| 8 | Full testing, responsive pass, deployment docs | |

## 9. Inconsistencies in the client document, and questions that need an answer

### Inconsistencies found
1. The sample DHM table and chord text show **8 chapters (3-3-2)**, which matches none of the three plans (5 / 7 / 9).
2. **"Main Outline Wish"** and **"revised wish"** are listed as features but never defined.
3. **"3×3 / 4×3 matrix"** is never defined; the DHM table itself has 4 columns.
4. **SAY point** is used two ways: a single element (P1 = Story, P2 = Evidence) and a mixed S+Y+A "Mixed Point". Numbering also repeats ("SAY Point 4 & 5", then P6, P7).
5. A chapter has **3 syntax strings** (9 elements) but only **2 subheadings × 3 SAY points** (6 points) — the mapping is unstated.
6. **ARC problem labels vary**: Chord 3 is "Identity/Essential" in one place and "Operational Problem" in another, and Awareness chapters 2–3 deliberately preview Resolution/Call-to-Action themes, so ARC alignment cannot be inferred mechanically.
7. The SOT chain paragraph says "approach to **creativity**" while Chapter 3's sentence says "approach to **collaboration**".
8. Founding plan lists no mini-courses; Basic omits *Just SAY It*. Probably intentional, but unconfirmed.
9. Product name appears as SAYBOOK, SAY BOOK and SAY BOOK App.

### Decisions I need from the client (ordered by impact)
| # | Question | My default (reversible) |
|---|---|---|
| Q1 | **Payment provider, tax, refunds, currency?** | Stripe-ready architecture only; no live payments |
| Q2 | **How does a user get a plan before payments exist?** Free preview? Admin grant? | Admin/service-role grant via script for testing |
| Q3 | **What is the "3×3 / 4×3 matrix"?** | A configurable grid label; I'd interpret it as subheadings × SAY points per chapter (3×3 = 3 subheadings of 3 points) |
| Q4 | **What is a Main Outline Wish, and does SAYBOOK generate the outline from it (AI?) or is it an author-written goal statement?** | Author-written; stored with history; no AI generation |
| Q5 | **Are wish revisions per book or per purchase?** And **one book per purchase, or many?** | Counted per project; multiple projects allowed |
| Q6 | **Founding "customizable ARC" rules** | Total stays 9; each Chord keeps ≥1 chapter |
| Q7 | **"Upgrade in 10 minutes, pay only the difference"** — window starts when? what happens to existing projects? | Not implemented; data model supports a plan change |
| Q8 | **Editable PDF: blank template or filled with the author's DHM?** | Filled, with editable fields |
| Q9 | Syntax strings always exactly 3 elements? How do strings map to SAY points? | 3 elements; a string is a reference pattern, points are attached per subheading |
| Q10 | Founder seats: reserve at checkout? Show seats remaining publicly? | Count completed purchases only; show nothing until confirmed |
| Q11 | Hosting, domain, auth options (social login?), brand colours/logo | Vercel; email/password; navy/charcoal + warm off-white |
| Q12 | How are e-books/courses/masterclass delivered, and when will content arrive? | Entitlement slots only |

## Verification done in this stage

- `node scripts/verify-core.mts`: **21 checks pass** — prices, 5/7/9 chapters, 1-3-1 / 2-3-2 / 3-4-2, revised-wish limits, ARC customization rules, skeletons for all three plans with continuous numbering, parsing of the client's `SYA+ ASA+ YAA`, and a check that the SQL plan seed equals `plans.ts`.
- `tsc` (strict, `noUncheckedIndexedAccess`) passes on the domain layer.
- Migration + `supabase/tests/schema_test.sql` run on a real Postgres 16 (with a stubbed `auth` schema): plan seeds, signup trigger, ARC enforcement, chapter caps, wish limits, syntax constraints, subscription self-grant blocked, cross-user read/write blocked, cascades. **Not yet run against an actual Supabase project.**
- **Not verified:** anything involving Next.js, React, Tailwind, Supabase Auth or the PDF — none of it exists yet.
