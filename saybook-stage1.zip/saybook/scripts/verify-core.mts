/**
 * Dependency-free checks for the DHM core. Run:  node scripts/verify-core.mts
 * (Node 22.18+ runs TypeScript directly.) Exits non-zero on any failure.
 */
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import {
  PLANS,
  PLAN_IDS,
  CHORD_ORDER,
  sumArc,
  validateArc,
  formatArc,
  canUseRevisedWish,
} from "../src/lib/plans.ts";
import { parseSyntax, formatSyntax, describeString, slotCount } from "../src/lib/dhm/syntax.ts";
import { createSkeleton } from "../src/lib/dhm/skeleton.ts";
import { allChapters } from "../src/lib/dhm/types.ts";

let passed = 0;
function check(name: string, fn: () => void) {
  fn();
  passed++;
  console.log(`  ok  ${name}`);
}

// --- Plans match the client document ---------------------------------------
check("plan prices", () => {
  assert.deepEqual(
    PLAN_IDS.map((id) => PLANS[id].priceUsd),
    [59, 79, 199],
  );
});
check("chapter counts 5 / 7 / 9", () => {
  assert.deepEqual(
    PLAN_IDS.map((id) => PLANS[id].chapterCount),
    [5, 7, 9],
  );
});
check("ARC labels 1-3-1 / 2-3-2 / 3-4-2", () => {
  assert.deepEqual(
    PLAN_IDS.map((id) => formatArc(PLANS[id].arc)),
    ["1-3-1", "2-3-2", "3-4-2"],
  );
});
check("every plan's ARC sums to its chapterCount", () => {
  for (const id of PLAN_IDS) assert.equal(sumArc(PLANS[id].arc), PLANS[id].chapterCount, id);
});
check("revised wishes 1 / 2 / 3", () => {
  assert.deepEqual(
    PLAN_IDS.map((id) => PLANS[id].revisedWishes),
    [1, 2, 3],
  );
});
check("e-book counts 2 / 3 / 6", () => {
  assert.deepEqual(
    PLAN_IDS.map((id) => PLANS[id].ebooks.length),
    [2, 3, 6],
  );
});
check("founder seat limit is 50 and only on founding", () => {
  assert.equal(PLANS.founding.seatLimit, 50);
  assert.equal(PLANS.basic.seatLimit, null);
  assert.equal(PLANS.standard.seatLimit, null);
});
check("revised-wish limit enforcement", () => {
  assert.equal(canUseRevisedWish(PLANS.basic, 0), true);
  assert.equal(canUseRevisedWish(PLANS.basic, 1), false);
  assert.equal(canUseRevisedWish(PLANS.founding, 2), true);
  assert.equal(canUseRevisedWish(PLANS.founding, 3), false);
});

// --- ARC validation / customization ----------------------------------------
check("basic and standard reject a customized ARC", () => {
  assert.equal(validateArc(PLANS.basic, { A: 2, R: 2, C: 1 }).ok, false);
  assert.equal(validateArc(PLANS.standard, { A: 3, R: 3, C: 1 }).ok, false);
});
check("founding accepts a 9-chapter redistribution", () => {
  assert.equal(validateArc(PLANS.founding, { A: 2, R: 4, C: 3 }).ok, true);
});
check("founding rejects wrong total or an empty Chord", () => {
  assert.equal(validateArc(PLANS.founding, { A: 3, R: 4, C: 3 }).ok, false);
  assert.equal(validateArc(PLANS.founding, { A: 0, R: 5, C: 4 }).ok, false);
});

// --- Skeleton generation per plan ------------------------------------------
for (const id of PLAN_IDS) {
  check(`skeleton for ${id}: distribution + continuous numbering`, () => {
    const dhm = createSkeleton(id);
    assert.deepEqual(
      dhm.chords.map((c) => c.key),
      [...CHORD_ORDER],
    );
    assert.deepEqual(
      dhm.chords.map((c) => c.chapters.length),
      CHORD_ORDER.map((k) => PLANS[id].arc[k]),
    );
    const numbers = allChapters(dhm).map((c) => c.number);
    assert.deepEqual(
      numbers,
      Array.from({ length: PLANS[id].chapterCount }, (_, i) => i + 1),
    );
    assert.equal(new Set(allChapters(dhm).map((c) => c.id)).size, PLANS[id].chapterCount);
  });
}
check("custom founding skeleton uses the custom ARC", () => {
  const dhm = createSkeleton("founding", { A: 2, R: 4, C: 3 });
  assert.deepEqual(
    dhm.chords.map((c) => c.chapters.length),
    [2, 4, 3],
  );
});
check("skeleton refuses an invalid ARC", () => {
  assert.throws(() => createSkeleton("basic", { A: 2, R: 2, C: 1 }));
});

// --- SAY syntax ------------------------------------------------------------
check("parses the client's Chapter 1 example 'SYA+ ASA+ YAA'", () => {
  const r = parseSyntax("SYA+ ASA+ YAA");
  assert.ok(r.ok);
  assert.equal(formatSyntax(r.syntax), "SYA + ASA + YAA");
  assert.equal(r.syntax.length, 3);
  assert.equal(slotCount(r.syntax), 9);
});
check("parsing is case-insensitive", () => {
  const r = parseSyntax("sya + asa");
  assert.ok(r.ok);
  assert.equal(formatSyntax(r.syntax), "SYA + ASA");
});
check("rejects invalid syntax", () => {
  assert.equal(parseSyntax("").ok, false);
  assert.equal(parseSyntax("SYX").ok, false);
  assert.equal(parseSyntax("SY").ok, false);
  assert.equal(parseSyntax("SYA++ASA").ok, false);
});
check("describes SYA from its letters", () => {
  const r = parseSyntax("SYA");
  assert.ok(r.ok);
  assert.equal(describeString(r.syntax[0]!), "Story, then Yielded Evidence, then Advice");
});

// --- SQL seed stays in sync with plans.ts -----------------------------------
check("SQL plan seed matches plans.ts", () => {
  const sql = readFileSync(new URL("../supabase/migrations/0001_init.sql", import.meta.url), "utf8");
  for (const id of PLAN_IDS) {
    const p = PLANS[id];
    const row = new RegExp(
      `\\('${id}',\\s*'${p.name}',\\s*${p.priceUsd * 100},\\s*${p.revisedWishes},\\s*${p.chapterCount},\\s*${p.arc.A},\\s*${p.arc.R},\\s*${p.arc.C},\\s*${p.customizableArc},\\s*${p.seatLimit ?? "null"}\\)`,
    );
    assert.match(sql, row, `plan row for ${id}`);
  }
});

console.log(`\n${passed} checks passed`);
